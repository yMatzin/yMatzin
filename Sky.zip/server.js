"$TOEKN"
// if you need help ask in the help channel dont dm me
 const { default_prefix } = require("./config.json")
 const DisTube = require("distube")
 
const prefix = 's.'
const { config } = require("dotenv");
const fetch = require("node-fetch");
const db = require("quick.db");
const moment = require("moment");
const { CanvasSenpai } = require("canvas-senpai")
const canva = new CanvasSenpai();
const { emotes , emoji} =require("./config.json")
const Discord = require("discord.js");
const client = new Discord.Client({
  disableEveryone: false
});
const yts = require('yt-search')

client.queue = new Map();
client.vote = new Map();
const { ready } = require("./handlers/ready.js")

client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();

["command"].forEach(handler => {
  require(`./handlers/${handler}`)(client);
});
client.queue = new Map()
process.on('unhandledRejection', console.error);

  
client.on("message", async message => {
 

  if (message.author.bot) return;
  if (!message.guild) return;
  if (!message.content.startsWith(default_prefix)) return;

  if (!message.member)
    message.member = message.guild.fetchMember(message);

  const args = message.content
    .slice(default_prefix.length)
    .trim()
    .split(/ +/g);
  const cmd = args.shift().toLowerCase();

  if (cmd.length === 0) return;

  let command = client.commands.get(cmd);

  if (!command) command = client.commands.get(client.aliases.get(cmd));

  if (command) command.run(client, message, args);
});

const enmap = require('enmap');

const settings = new enmap({
    name: "settings",
    autoFetch: true,
    cloneLevel: "deep",
    fetchAll: true
});

client.on('message', async message => {
    if(message.author.bot) return;
    if(message.content.indexOf(prefix) !== 0) return;
;

    const prefix_detect = message.content.slice(prefix.length).trim().split(/ +/g);
    const command_detect = prefix_detect.shift().toLowerCase();
    const emoji = "🎫";

        let ticket_ok = new Discord.MessageEmbed()
            .setTitle("✅ |Sistema de Ticket")
            .setDescription("Você configurou o sistema de ticket com sucesso!")
            .setFooter("Sistema de Ticket")
            .setColor("RANDOM")

        let ticket_error = new Discord.MessageEmbed()
            .setTitle("❌ |Sistema de Ticket")
            .setDescription("Você errou ao digitar o comando!\n✅ |O correto: \`s.ticket-setup #canal\`")
            .setFooter("Sistema de Ticket")
            .setColor("RANDOM")

    if(command_detect == "ticket-setup") {

        let error = message.mentions.channels.first();
        if(!error) return message.reply(ticket_error);

        let ticket = await error.send(new Discord.MessageEmbed()
            .setTitle("Sistema de Ticket")
            .setDescription("Reaja 🎫 para abrir um ticket!\nPara fecha-lo, utilize s.close!")
            .setFooter("Sistema de Ticket")
            .setColor("RANDOM")
        );

        ticket.react(emoji);
        settings.set(`${message.guild.id}-ticket`, ticket.id);

        message.channel.send(ticket_ok)
    }

    if(command_detect == "close") {
        if(!message.channel.name.includes("ticket-")) return message.channel.send("Você não pode utilizar esse comando aqui!")
        message.channel.delete();
    }
});

client.on('messageReactionAdd', async (reaction, user) => {
  const ticket_emoji = "🎫";
    if(user.partial) await user.fetch();
    if(reaction.partial) await reaction.fetch();
    if(reaction.message.partial) await reaction.message.fetch();

    if(user.bot) return;

    const ticket = await settings.get(`${reaction.message.guild.id}-ticket`);

    if(!ticket) return;

    if(reaction.message.id == ticket && reaction.emoji.name == ticket_emoji) {
        reaction.users.remove(user);

        reaction.message.guild.channels.create(`ticket-${user.username}`, {
            permissionOverwrites: [
                {
                    id: user.id,
                    allow: ["SEND_MESSAGES", "VIEW_CHANNEL"]
                },
                {
                    id: reaction.message.guild.roles.everyone,
                    deny: ["VIEW_CHANNEL"]
                }
            ],
            type: 'text'
        }).then(async ticket => {
            ticket.send(`<@${user.id}>`, new Discord.MessageEmbed().setTitle("Boas vindas ao seu ticket").setDescription("Para fecha-lo, utilize \`s.close\`").setColor("RANDOM"));
            
        })
    }
});

  client.on("message", message => {
	let mencao = new Discord.MessageEmbed()
		.setTitle('Olá! Sou Sky <:sky:851480850360041533>')
		.setDescription('Entre em meu servidor [Clicando Aqui](https://discord.gg/9zequXaNwP)')
		.addFields(
            {
                name: "Prefix",
                value: "Meu prefix é `s.`",
                inline: true
            },
            {
                name: "Ajuda",
                value: "Utilize `s.ajuda` para ver meus comandos!",
                inline: false
            },
            {
              name: "Criador",
              value: `Meu criador é o yMatzin#8622`,
              inline: false
            },
            {
              name: "Versão",
              value: `<:javascript:851864661359591495> v2.8`,
              inline: false
            },
        );

    if (message.author.bot) return;
    if (message.channel.type == 'ferinha')
    return
    if(message.content == `<@${client.user.id}>` || message.content == `<@!${client.user.id}>`) {
    return message.channel.send(mencao)
    }
    }); 

  client.on("guildCreate", function(guild){ 
  
  let user = client.users.cache.get("843548736730562580")

  const msg = new Discord.MessageEmbed()
    .setColor('RANDOM')
    .setTitle(`${client.user.username} está em um novo servidor.`)
    .setDescription(`**Nome: \`${guild.name}\`\nID: \`${guild.id}\`\nMembros: \`${guild.memberCount}\`\nTotal de servidores: \`${client.guilds.cache.size}\`**`)
    
    .setTimestamp()
  user.send(msg);
});

client.on("message", msg => {
	let dm = new Discord.MessageEmbed()
		.setTitle('Olá! Sou Sky <:sky:851480850360041533>')
		.setDescription('Entre em meu servidor [Clicando Aqui](https://discord.gg/9zequXaNwP)');
  if (msg.author.bot) return;
  if (msg.channel.type == 'dm') return msg.reply(dm)
});


client.on("message", async message => {

let afk = new db.table("AFKs"),
      authorStatus = await afk.fetch(message.author.id),
      mentioned = message.mentions.members.first();
  
  if (mentioned) {
    let status = await afk.fetch(mentioned.id);
    
    if (status) {
      let afk_ativo = new Discord.MessageEmbed()

      .setTitle(` ${message.author.tag} Esta No Modo Afk.`)
      .setDescription(``)

     message.channel.send(afk_ativo)

    }
  }
  
  if (authorStatus) {
          let afk_off = new Discord.MessageEmbed()

      .setTitle(` ${message.author.tag} Saiu Do Modo Afk.`)
      .setDescription(``)
      .setColor(`#FF0000`)

     message.channel.send(afk_off).then(i => i.delete({timeout: 10000}));
    afk.delete(message.author.id)
  }
})

client.on("guildMemberAdd", async member => {

  let chx = db.get(`welchannel_${member.guild.id}`);

  if (chx === null) {

    return;

  }
 let data = await canva.welcome(member, { link: "https://cdn.discordapp.com/attachments/815889737750544405/827575020338675822/welcome_imgae.png",blur: false }) 
   const attachment = new Discord.MessageAttachment(

      data,

      "welcome-image.png"

    );
 client.channels.cache.get(chx).send(`Bem Vindo ao ${member.guild.name}, ${member.user}\nVocê é o nosso ${member.guild.memberCount} Membro!. Divirta-se `, attachment);

});

const { GiveawaysManager } = require("discord-giveaways");
const manager = new GiveawaysManager(client, {
    storage: "./handlers/giveaways.json",
    updateCountdownEvery: 10000,
    default: {
        botsCanWin: false,
        exemptPermissions: [ "MANAGE_MESSAGES", "ADMINISTRATOR" ],
        embedColor: "#FF0000",
        reaction: "🎉"
    }
});
// We now have a giveawaysManager property to access the manager everywhere!
client.giveawaysManager = manager;

client.on("message", async message => {
if(!message.guild) return;
  let prefix = db.get(`default_prefix${message.guild.id}`)
  if(prefix === null) prefix =default_prefix;
  
  if(!message.content.startsWith(default_prefix)) return;
 
})


client.on("ready", () => {

    let ferinha = [
        `Minhas Atualizações`,
        `${client.guilds.cache.size} Grupos`,
        `${client.users.cache.size} Pessoas`,
        `Site: https://sitesky.glitch.me/#`,
        `🙃`,
        `😁`,
        `😊`,
        `😎`
      ],
      fera = 0;
      let cepardo = [
          'WATCHING',
          'WATCHING',
          'WATCHING',
          'LISTENING',
          'PLAYING',
          'PLAYING',
          'PLAYING',
          'PLAYING'
      ],
      cep = 0;
    
    setInterval( () => client.user.setActivity(`${ferinha[fera++ % ferinha.length]}`, {
          type: `${cepardo[cep++ % cepardo.length]}` //mais tipos: WATCHING / LISTENING
        }), 3000); 
    client.user
        .setStatus("online")
        .catch(console.error);
  console.log("Estou pronto(a) para ser utilizado(a)!")
  });

client.on("message", async message => {
if(!message.guild) return;
  let prefix = db.get(`prefix_${message.guild.id}`)
  if(prefix === null) prefix = default_prefix;
  
  if(!message.content.startsWith(prefix)) return;
 
})
 

require('http').createServer((req, res) => res.end('Bot Online!')).listen(3000)

const { Player } = require("discord-music-player");
const player = new Player(client, {
    leaveOnEmpty: false,
});

client.player = player;

new Player(client, {
    leaveOnEnd: true,
    leaveOnStop: true,
    leaveOnEmpty: true,
    timeout: 10,
    volume: 50,
    quality: 'normal',
});

 client.on('guildCreate', guild =>{

    const channelId = '843548736730562580'; //put your channel ID here

    const channel = client.channels.cache.get(channelId); 
     //This Gets The Guild Owner
    if(!channel) return; //If the channel is invalid it returns
    const embed = new discord.MessageEmbed()
        .setTitle('Eu entrei em um servidor!!')
        .setDescription(`**Nome:** ${guild.name} | ${guild.id}\n**Membros:** ${guild.memberCount}`)
        .setTimestamp()
        .setColor('RANDOM')
        .setFooter(`Estou em ${client.guilds.cache.size} servidores agora!`);
    channel.send(embed);
});


client.on('guildDelete', guild =>{
    const channelId = '843548736730562580';//add your channel ID
    const channel = client.channels.cache.get(channelId); //This Gets That Channel
    
    if(!channel) return;  //If the channel is invalid it returns
    const embed = new discord.MessageEmbed()
        .setTitle('Eu sai de um servidor!!')
        .setDescription(`**Nome:** ${guild.name} | ${guild.id}\n**Membros:** ${guild.memberCount}`)
        .setTimestamp()
        .setColor('RED')
        .setFooter(`Estou em ${client.guilds.cache.size} servidores agora :(`);
    channel.send(embed);
});

require("./ExtendedMessage");


    allowedMentions: {
        // set repliedUser value to `false` to turn off the mention by default
        repliedUser: true
    }
    
    

client.login(process.env.TOKEN);