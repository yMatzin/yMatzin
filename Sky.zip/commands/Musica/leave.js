const { MessageEmbed } = require("discord.js");

module.exports = {
    name: 'leave', // Optional
    aliases: [], // Optional
    category: 'Musica',
    description: 'Leaves the voice channel!', 
        
        run: async (client, message, args) => {
            const voiceChannel = message.member.voice.channel;
            const embed = new MessageEmbed()
            .setColor('#FF5757')
            .setDescription(`Você precisa estar em uma chamada de voz para executar esse comando!`)
            if(!voiceChannel) return message.channel.send(embed)
            voiceChannel.leave()
            message.react('🪐')
              
          }
}