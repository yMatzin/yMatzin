const { MessageEmbed } = require("discord.js");

module.exports = {
    name: 'skip', // Optional
    aliases: ['s'], // Optional
    category: 'Musica',
    description: 'Skip the song that its playing.', 
        run: async (client, message, args) => {
            const voice_channel = message.member.voice.channel;
            const embed = new MessageEmbed()
            .setColor('#FF5757')
            .setDescription(`Você precisa estar em uma chamada de voz para executar esse comando!`)
            if(!client.player.isPlaying(message)) {
			message.channel.send('Uma musica deve estar tocando!');

			return;
		}

		await client.player.skip(message);

		message.channel.send('Skipped');
	},
};