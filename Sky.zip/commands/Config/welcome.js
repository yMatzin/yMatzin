const Discord = require("discord.js")
const db = require("quick.db")

module.exports = {
  name: "setwelcome",
  aliases: ["setentrada"],
  category: "Configuraveis",
  usage: "setwelcome <#channel>",
  description: "Seta msg de boas vindas ué '-'",
  run: (client, message, args) => {
     if (!message.member.hasPermission("MANAGE_GUILDS")) {
      return message.channel.send("Você não tem permição");
    }
    let channel = message.mentions.channels.first()
    
    if(!channel) {
      return message.channel.send("Mensione um canal!")
    }
    
    db.set(`welchannel_${message.guild.id}`, channel.id)
    
    message.channel.send(`Mensagem de boas-vindas setada em ${channel}`)
  }
}