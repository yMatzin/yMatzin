const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "help",
  description:
    "Get list of all command and even get to know every command detials",
  usage: "help <cmd>",
  category: "Bot",
  run: async (client, message, args) => {
    
    if (args[0]) {
      const command = await client.commands.get(args[0]);

      if (!command) {
        return message.channel.send("Comando Desconhecido: " + args[0]);
      }

      let embed = new MessageEmbed()
        .setAuthor(command.name, client.user.displayAvatarURL())
        .addField("❯ Descrição", command.description || "Sem")
        .addField("❯ Modo De Uso", "`" + command.usage + "`" || "Sem")
        .setThumbnail(client.user.displayAvatarURL())
        .setColor("#868686")
        .setFooter(client.user.username, client.user.displayAvatarURL());

      return message.channel.send(embed);
    } else {
      
      const commands = await client.commands;

      let emx = new MessageEmbed()
        .setDescription(`**Olá, aqui meu painel de comandos!**\nCaso queira saber mais sobre um comando, utilize: \`**s.help <cmd>**\``)
  
        .setColor("#868686")
        .setFooter(client.user.username, client.user.displayAvatarURL())
        
        .setThumbnail(client.user.displayAvatarURL());
          
      let com = {};
      for (let comm of commands.array()) {
        let category = comm.category || "Desconhecidos";
        let name = comm.name;

        if (!com[category]) {
          com[category] = [];
        }
        com[category].push(name);
      }

      for(const [key, value] of Object.entries(com)) {
        let category = key;

        let desc = "`" + value.join("`, `") + "`";

        emx.addField(`${category.toUpperCase()}[${value.length}]`, desc);
      }
     emx.addField('🥇 Links Importantes ','**[Suporte](https://discord.gg/9zequXaNwP)**  | **[Meu Site](https://sitesky.glitch.me/#)**')
      return message.inlineReply({
  embed: emx,
})

    }
  }
};
