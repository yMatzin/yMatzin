const Discord = require('discord.js');

module.exports = {
  name: "reportbug",
  aliases: ["bug"],
  category: "Bot",
  description: "Reporte um bug que tem no sky '-'",
  usage: "reportbug <bug>",
  run: (client, message, args) => {

const hora = new Date();
hora.setHours(hora.getHours() - 3);
message.delete().catch(O_o => {});
const reason = args.join(' ');
if(!reason) return message.reply("Você precisa me dizer o bug que quer reportar!").then(msg => msg.delete({timeout: 5000}))

//Mensagem na Log
console.log(`
=================================
Bug Reportado!

Bug: ${reason}
Reportado por: ${message.author.tag} ID: ${message.author.id}
Hora: ${hora.getUTCHours()}:${hora.getUTCMinutes()}:${hora.getUTCSeconds()}
=================================`);

//Mensagem no Privado
const privado = new Discord.MessageEmbed()
.setTitle(`**Bug reportado!**`)
.setColor(`RED`)
.setThumbnail('https://media1.giphy.com/media/5xaOcLyjXRo4hX5UhSU/200_d.gif')
.setDescription(`${message.author} muito obrigado por nos reportar o bug **${reason}**, caso seja necessário nossa equipe entrará em contato com você!`)
.setFooter(`O mal uso desse comando pode resultar em punição!`) 
message.author.send(privado);
}
}