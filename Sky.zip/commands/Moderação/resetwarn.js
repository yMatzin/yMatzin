const db = require("quick.db");

module.exports = {
  name: "resetwarns",
  aliases: ["rwarns", "rsetwarns"],
  category: "Moderação",
  usage: "rwarns <@user>",
  description: "Reset warnings of mentioned person",
  run: async (client, message, args) => {
    if (!message.member.hasPermission("ADMINISTRATOR")) {
      return message.channel.send(
        "Você não tem permição!"
      );
    }

    const user = message.mentions.members.first();

    if (!user) {
      return message.channel.send("Por favor, mensione alguém");
    }

    if (message.mentions.users.first().bot) {
      return message.channel.send("Bots não podem ser avisados! ");
    }

    if (message.author.id === user.id) {
      return message.channel.send("Você não pode remover warns de si mesmo");
    }

    let warnings = db.get(`warnings_${message.guild.id}_${user.id}`);

    if (warnings === null) {
      return message.channel.send(`${message.mentions.users.first().username} não tem warns`);
    }

    db.delete(`warnings_${message.guild.id}_${user.id}`);
    user.send(
      `Todos os warns de ${message.author.username} do servidor ${message.guild.name} foram removidos`
    );
    await message.channel.send(
      `Todos os warns de ${message.mentions.users.first().username} foram removidos`
    );
  }
};
