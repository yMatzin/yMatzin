const Discord = require("discord.js");

module.exports = {
  name: "say",
  aliases: ['falar'],
  category: 'Moderação',
  
  run: async(client, message, args) => {

    if (!message.member.permissions.has("MANAGE_MESSAGES"))
    return message.reply(
      ":x: |Você não tem permição para utilizar este comando!"
    );
  
    let msg = args.join(" ");

    if (!msg) return message.channel.send(`:x: | ${message.author} não encontrei nada para falar!`);

    message.channel.send(`${msg}`)
  }
}