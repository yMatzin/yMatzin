const discord = require("discord.js");

module.exports = {
  name: "ban",
  category: "Moderação",
  description: "ban 'p'",
  usage: "ban <@user> <reason>",
  run: async (client, message, args) => {
    
    const target = message.mentions.members.first()
    
    const reason = args.slice(1).join(" ")
    
    if(!message.member.hasPermission("BAN_MEMBERS")) return message.reply(`Você não tem permição! - [BAN_MEMBERS]`)
    
    if(!message.guild.me.hasPermission("BAN_MEMBERS")) return message.reply(`Eu não tenho permição! - [BAN_MEMBERS]`)
    
    if(!args[0]) return message.reply(`Mensione alguém!`)
    
    if(!target) return message.reply(`Não achei esse membro!`)
    
    if(target.roles.highest.position >= message.member.roles.highest.position || message.author.id !== message.guild.owner.id) {
      return message.reply(`Você não tem poder suficiente!`)
    }
    
    if(target.id === message.author.id) return message.reply(`Eu não posso te banir!`)
    
    if(target.bannable) {
      let embed = new discord.MessageEmbed()
      .setColor("RANDOM")
      .setDescription(`Usuario Banido: \`${target}\` \n Motivo: \`${reason || "Nenhum Motivo"}\``)
      
      message.channel.send(embed)
      
      target.ban()
      
      message.delete()
      
    } else {
      return message.reply(`Essa pessoa tem um cargo maior que o meu!`)
    }
    return undefined
  }
};