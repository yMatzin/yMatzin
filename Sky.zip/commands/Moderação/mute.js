const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "mute",
  aliases: ["mutes", "muted"],
  category: "Moderação",
  description: "mute @user",
  run: async (client, message, args) => {
    if (!message.member.hasPermission("MANAGE_ROLES")) {
      return message.channel.send("Você não tem permição!");
    }
    if (!message.guild.me.hasPermission("MANAGE_ROLES")) {
      return message.channel.send("Eu não tenho permição!");
    }

    const user = message.mentions.members.first();

    if (!user) {
      return message.channel.send("\```Mensione um usuario\```");
    }
    if (user.id === message.author.id) {
      return message.channel.send("Eu não posso te mutar!");
    }
    let reason = args.slice(1).join("");

    if (!reason) {
      return message.channel.send(" \``` Me diga o motivo do mute\``` ");
    }

    const vrole = user.roles.cache

    let muterole = message.guild.roles.cache.find(x => x.name === "muted");

    if (!muterole) {
      return message.channel.send("\```Por Favor, crie um cargo para mutados! \``` ");
    }
    
    await user.roles.remove(vrole);
    await user.roles.add(muterole);

    await message.channel.send(
      `Você foi mutado ${message.mentions.users.first().username} por ${reason}`
    );

    user.send(`VocÊ foi mutado no servidor ${message.guild} por ${reason}`
    );
  }
};
