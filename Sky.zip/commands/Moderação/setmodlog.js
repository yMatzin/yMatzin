const db = require("quick.db")

module.exports = {
  name: "setmodlog",
  description: "set mod log cgannel",
  category: "Configuraveis",

 run: async (bot, message, args) => {
        if (!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send("**Você não tem permição! - [ADMINISTRATOR]**")
    if (!args[0]) {
      let b = await db.fetch(`modlog_${message.guild.id}`);
      let channelName = message.guild.channels.cache.get(b);
      if (message.guild.channels.cache.has(b)) {
        return message.channel.send(
          `**Modlog Setado no chat \`${channelName.name}\`!**`
        );
      } else
        return message.channel.send(
          "**Mensione o chat, ou mande um id!**"
        );
    }
        let channel = message.mentions.channels.first() || bot.guilds.cache.get(message.guild.id).channels.cache.get(args[0]) || message.guild.channels.cache.find(c => c.name.toLowerCase() === args.join(' ').toLocaleLowerCase());

        if (!channel || channel.type !== 'text') return message.channel.send("**Mensione um chat \`VÁLIDO\`!**");

        try {
            let a = await db.fetch(`modlog_${message.guild.id}`)

            if (channel.id === a) {
                return message.channel.send("**Esse chat, agora é o chat de ModLogs!**")
            } else {
                bot.guilds.cache.get(message.guild.id).channels.cache.get(channel.id).send("**Modlog Setado!!**")
                db.set(`modlog_${message.guild.id}`, channel.id)

                message.channel.send(`**Modlog setado no chat \`${channel.name}\`!**`)
            }
        } catch {
            return message.channel.send("**Error - `Não tenho permições para este chat, ou ele não existe!`**");
        }
    }
};