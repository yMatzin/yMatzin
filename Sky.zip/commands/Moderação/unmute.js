const db = require("quick.db");

module.exports = {
  name: "unmute",
  category: "Moderação",
  run: async (client, message, args) => {
    if (!message.member.hasPermission("MANAGE_ROLES")) {
      return message.channel.send(
        "Você não tem permição!"
      );
    }

    if (!message.guild.me.hasPermission("MANAGE_ROLES")) {
      return message.channel.send("Eu não tenho permição!");
    }

    const user = message.mentions.members.first();

    if (!user) {
      return message.channel.send("Mensione um membro \`MUTADO\` para ser desmutado!");
    }

    let muterole = message.guild.roles.cache.find(x => x.name === "Muted");

    if (user.roles.cache.has(muterole)) {
      return message.channel.send("Não tem um cargo setado como Mutado!");
    }

    user.roles.remove(muterole)

    await message.channel.send(`**${message.mentions.users.first().username}** foi desmutado!`);

    user.send(`Você foi desmutado do servidor **${message.guild.name}**`);
    
    message.delete()
  }
};
