const Discord = require("discord.js");
const bot = new Discord.Client();
module.exports = {
  name: "purge",
  category: "Moderação",
  aliases: ['clear', 'delete', 'prune', 'limpar'],

  async run(bot, message, args) {
// UPDATE ^ ACCORDING TO YOUR HANDLER
let prefix = "s."
 try { 
 
   if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.reply("Você não tem permição!.");
  if(!message.guild.me.hasPermission("MANAGE_MESSAGES")) return message.reply("Eu não tenho permição!");

const commands = [
`bots\` - Deleta apenas mensagens de bots.`, 
`humans\` - Deleta apenas mensagens de humanos.`, 
`embeds\` - Deleta apenas embeds.`, 
`files\` - Deleta apenas arquivos`, 
`mentions\` - Deleta apenas menções`, 
`text\` - Deleta apenas textos`, 
]

const embd = new Discord.MessageEmbed() 
.setColor("BLUE") 
.setTitle("Purge | Clear | Delete | Prune") 
.setDescription(`Modos de clear`)
.addFields(
    {
      name: "Bots",
      value: "Deleta apenas mensagens de bots",
      inline: false,
    },
    {
      name: "Humans",
      value: "Deleta apenas mensagens de humanos",
      inline: false,
    },
    {
      name: "Embes",
      value: "Deleta apenas embeds",
      inline: false,
    },
    {
      name: "Files",
      value: "Deleta apenas arquivos",
      inline: false,
    },
    {
      name: "Mentions",
      value: "Deleta apenas menções",
      inline: false,
    },
    {
      name: "Text",
      value: "Deleta apenas textos",
      inline: false,
    },
)
.setFooter(`${prefix}purge, ${prefix}clear, ${prefix}delete, ${prefix}prune, ${prefix}limpar`) 




if(!args[0] || !args.length) return message.channel.send(embd);
let amount = Number(args[0],10) || parseInt(args[0]);
if(isNaN(amount) || !Number.isInteger(amount)) return message.channel.send("Coloque um numero de 2 a 100.");
if(!amount || amount < 2 || amount > 100) return message.channel.send("Coloque um numero de 2 a 100.")
if(!args[1]) {

try {
  await message.delete()
await message.channel.bulkDelete(amount).then(async (m) => { 
  
   let embed = new Discord.MessageEmbed()
  .setColor('0x#00ffff')
  .setDescription(`✅ **${m.size}**/**${amount}** Limpas deste chat!!`);

   message.channel.send(embed).then(msg => msg.delete({timeout:4000})); 
})

   } catch (e) { 
     console.log(e) 
     message.channel.send(`Mensagens com mais de 14 dias não serão apagadas!`)
     

   }

} else if(args[1]) {
  let msg;
  let data;
  let embed;
  switch(args[1]) {
    case "--bots":
     msg = await message.channel.messages.fetch({limit: amount})
    data = []
    msg.map(m => m).forEach(ms => {
      if(ms.author.bot && !ms.pinned) data.push(ms)
    })
   
   try {
     await message.delete()
     await message.channel.bulkDelete(data.length ? data : 1, true).then(async (m) => {
      
      embed = new Discord.MessageEmbed()
  .setColor('0x#00ffff')
  .setDescription(`✅ **${m.size}**/**${amount}** Limpas deste chat!!`);

   message.channel.send(embed).then(msg => msg.delete({timeout:50000})); 
      })
      
   } catch (e) { 
     console.log(e)
   message.channel.send(`Mensagens com mais de 14 dias não serão apagadas!`) 
   }

      break;
     case "--humans":
     msg = await message.channel.messages.fetch({limit: amount})
     data = []
    msg.map(m => m).forEach(ms => {
      if(!ms.author.bot && !ms.pinned) data.push(ms)
    })
    
   try {
     
     await message.channel.bulkDelete(data.length ? data : 1, true).then(async (m) => {
      
      embed = new Discord.MessageEmbed()
  .setColor('0x#00ffff')
  .setDescription(`✅ **${m.size}**/**${amount}** Limpas deste chat!!`);

   message.channel.send(embed).then(msg => msg.delete({timeout:50000})); 
      })
      
   } catch (e) { 
     console.log(e)
   message.channel.send(`Mensagens com mais de 14 dias não serão apagadas!`) 
   }

      break;
case "--embeds":
     msg = await message.channel.messages.fetch({limit: amount})
     data = []
    msg.map(m => m).forEach(ms => {
      if(ms.embeds.length && !ms.pinned) data.push(ms)
    })
    
   try {
     
      await message.channel.bulkDelete(data.length ? data : 1, true).then(async (m) => {
      
       embed = new Discord.MessageEmbed()
  .setColor('0x#00ffff')
  .setDescription(`✅ **${m.size}**/**${amount}** Limpas deste chat!!`);

   message.channel.send(embed).then(msg => msg.delete({timeout:50000})); 
      })
      
   } catch (e) { 
     console.log(e)
   message.channel.send(`Mensagens com mais de 14 dias não serão apagadas!`) 
   }

      break;
case "--files":
     msg = await message.channel.messages.fetch({limit: amount})
     data = []
    msg.map(m => m).forEach(ms => {
      if(ms.attachments.first() && !ms.pinned) data.push(ms)
    })
    
   try {
  
     await message.channel.bulkDelete(data.length ? data : 1, true).then(async (m) => {
      
       embed = new Discord.MessageEmbed()
  .setColor('0x#00ffff')
  .setDescription(`✅ **${m.size}**/**${amount}** Limpas deste chat!!`);

   message.channel.send(embed).then(msg => msg.delete({timeout:50000})); 
      })
      
   } catch (e) { 
     console.log(e)
   message.channel.send(`Mensagens com mais de 14 dias não serão apagadas!`) 
   }

      break;case "--text":
    msg = await message.channel.messages.fetch({limit: amount})
    data = []
    msg.map(m => m).forEach(ms => {
      if(!ms.attachments.first() && !ms.embeds.length && !ms.pinned) data.push(ms)
    })
    
   try {
     
     await message.channel.bulkDelete(data.length ? data : 1, true).then(async (m) => {
      
       embed = new Discord.MessageEmbed()
  .setColor('0x#00ffff')
  .setDescription(`✅ **${m.size}**/**${amount}** Limpas deste chat!!`);

   message.channel.send(embed).then(msg => msg.delete({timeout:50000})); 
      })
      
   } catch (e) { 
     console.log(e)
   message.channel.send(`Mensagens com mais de 14 dias não serão apagadas!`) 
   }

      break;
  case "--mentions":
     msg = await message.channel.messages.fetch({limit: amount})
  data = []
    msg.map(m => m).forEach(ms => {
      if((ms.mentions.users.first() || ms.mentions.members.first() || ms.mentions.channels.first() || ms.mentions.roles.first())&& !ms.pinned) data.push(ms)
    })
    
   try {
 
       await message.channel.bulkDelete(data.length ? data : 1, true).then(async (m) => {
      
       embed = new Discord.MessageEmbed()
  .setColor('0x#00ffff')
  .setDescription(`✅ **${m.size}**/**${amount}** Limpas deste chat!!`);

   message.channel.send(embed).then(msg => msg.delete({timeout:50000})); 
      })
      
   } catch (e) { 
     console.log(e)
   message.channel.send(`Mensagens com mais de 14 dias não serão apagadas!`) 
   }

      break;
case "--pins":
    msg = await message.channel.messages.fetch({limit: amount})
     data = []
    msg.map(m => m).forEach(ms => {
      if(ms.pinned) data.push(ms)
    })
    
   try {
     
     await message.channel.bulkDelete(data.length ? data : 1, true).then(async (m) => {
      
      embed = new Discord.MessageEmbed()
  .setColor('0x#00ffff')
  .setDescription(`✅ **${m.size}**/**${amount}** Limpas deste chat!!`);

   message.channel.send(embed).then(msg => msg.delete({timeout:50000})); 
      })
      
   } catch (e) { 
     console.log(e)
   message.channel.send(`Mensagens com mais de 14 dias não serão apagadas!`) 
   }

      break;
case "--match":
     msg = await message.channel.messages.fetch({limit: amount})
    data = []
    msg.map(m => m).forEach(ms => {
if(!args[2]) return message.channel.send(embd);
      if(ms.content.includes(args.slice(2).join(" ")) && !ms.pinned) data.push(ms)
    })
    
   try {
    
     
     await message.channel.bulkDelete(data.length ? data : 1, true).then(async (m) => {
      
       embed = new Discord.MessageEmbed()
  .setColor('0x#00ffff')
  .setDescription(`✅ **${m.size}**/**${amount}** Limpas deste chat!!`);

   message.channel.send(embed).then(msg => msg.delete({timeout:50000})); 
      })
      
   } catch (e) { 
     console.log(e)
   message.channel.send(`Mensagens com mais de 14 dias não serão apagadas!`) 
   }

      break;
case "--not":
    msg = await message.channel.messages.fetch({limit: amount})
     data = []
    msg.map(m => m).forEach(ms => {
if(!args[2]) return message.channel.send(embd);
      if(!ms.content.includes(args.slice(2).join(" ")) && !ms.pinned) data.push(ms)
    })
    
   try {
     
     await message.channel.bulkDelete(data.length ? data : 1, true).then(async (m) => {
      
       embed = new Discord.MessageEmbed()
  .setColor('0x#00ffff')
  .setDescription(`✅ **${m.size}**/**${amount}** Limpas deste chat!!`);

   message.channel.send(embed).then(msg => msg.delete({timeout:50000})); 
      })
      
   } catch (e) { 
     console.log(e)
   message.channel.send(`Mensagens com mais de 14 dias não serão apagadas!`) 
   }

      break;
case "--startswith":
     msg = await message.channel.messages.fetch({limit: amount})
     data = []
    msg.map(m => m).forEach(ms => {
if(!args[2]) return message.channel.send(embd);
      if(ms.content.startsWith(args.slice(2).join(" ")) && !ms.pinned) data.push(ms)
    })
    
   try {
     
     await message.channel.bulkDelete(data.length ? data : 1, true).then(async (m) => {
      
       embed = new Discord.MessageEmbed()
  .setColor('0x#00ffff')
  .setDescription(`✅ **${m.size}**/**${amount}** Limpas deste chat!!`);

   message.channel.send(embed).then(msg => msg.delete({timeout:50000})); 
      })
      
   } catch (e) { 
     console.log(e)
   message.channel.send(`Mensagens com mais de 14 dias não serão apagadas!`) 
   }

      break;
case "--endswith":
     msg = await message.channel.messages.fetch({limit: amount})
     data = []
    msg.map(m => m).forEach(ms => {
if(!args[2]) return message.channel.send(embd);
      if(ms.content.endsWith(args.slice(2).join(" ")) && !ms.pinned) data.push(ms)
    })
    
   try {
     
     await message.channel.bulkDelete(data.length ? data : 1, true).then(async (m) => {
      
       embed = new Discord.MessageEmbed()
  .setColor('0x#00ffff')
  .setDescription(`✅ **${m.size}**/**${amount}** Limpas deste chat!!`);

   message.channel.send(embed).then(msg => msg.delete({timeout:50000})); 
      })
      
   } catch (e) { 
     console.log(e)
   message.channel.send(`Mensagens com mais de 14 dias não serão apagadas!`) 
   }

      break;
default:
return message.channel.send(embd) 
break;
}

} else {
 return message.channel.send(`An error occoured.`)
}
} catch (error) {
  console.log(error)
  message.channel.send(`An error occurred: \`${error}\``)
}


}
}


