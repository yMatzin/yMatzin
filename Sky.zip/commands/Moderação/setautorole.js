const Discord = require("discord.js")
const db = require("quick.db");

module.exports = {
    name: "set autorole",
    aliases: ['autorole', 'autocargo'],
    category: 'Em Breve',

    run: async(client, message, args) => {
        let user = message.author;
        let error1 = new Discord.MessageEmbed()
    .setTitle(`Auto Role`)
    .setColor("#00FF00")
    .setDescription(`❌ |${user}, você não escreveu o comando corretamente!\n❌ |Tente: s.autorole @cargo`)
    .setFooter(`Sky Bot - Todos os direitos reservados ©`)
        if (!args[0]) return message.channel.send(error1)

        let autorole = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]);

        db.set(`autorole_${message.guild.id}`, autorole.id);

        let auto_role_ok = new Discord.MessageEmbed()
    .setTitle(`Auto Role`)
    .setColor("#00FF00")
    .setDescription(`✅ |${user}, o cargo **'${autorole}'** foi definido como cargo altomatico!`)
    .setFooter(`Sky Bot - Todos os direitos reservados ©`)

        message.channel.send(auto_role_ok)

    }
}