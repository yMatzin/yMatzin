const Discord = require('discord.js');

  module.exports = {
    name: "memes",
    description: "'-'",
    author: "Sky",
    category: 'Diversão',

run: async(client, message, args) => {

const list = [
  'https://static.wixstatic.com/media/72c0b2_2819c1101e554fca8a534cdce8e52b2d~mv2.png/v1/fill/w_924,h_459,al_c/72c0b2_2819c1101e554fca8a534cdce8e52b2d~mv2.png',
  'https://gritasaopaulo.com.br/wp-content/uploads/2020/11/meme-800x445.jpg',
  'https://memegenerator.net/img/instances/81906144/eu-economizo-pra-balada-se-comprar-o-ingresso-antecipado.jpg',
  'https://lh3.googleusercontent.com/proxy/3hxjuGnDgoFMw69Z7N61CW6YaVQRMDaL62bhj5KusJ1wSMUfBYjSePJpovFBWB7o_Vhgv6zlFU89CtJt8jZsOXQ_2giRGM9mtCv_b_yP89oghtHmPRyEI1hDEmQ',
  'https://img2.ibxk.com.br//2014/10/31/31092700980186.jpg?w=252&h=144&mode=crop&scale=both',
  'https://static-wp-tor15-prd.torcedores.com/wp-content/uploads/2020/10/spfc-meme-572x338.png',
  'http://pm1.narvii.com/7631/1b85e0879853a3403a01ebacacbec31404fe0988r1-828-666v2_uhq.jpg',
  'https://lh3.googleusercontent.com/proxy/h0ETATwgGCF--qsJBhN5Diu_IJEIJopfxtG_Cz4hdkIibV6eZpzKDeh32dEangQMvaqD2zbJPgQQ5vkR4h5KWNAmLy-j9WDJjm_4Ls2ddnU0LBrfuNn_Rw',
  'https://folhadonortepr.com.br/wp-content/uploads/2020/05/PAG-ECEL-SUCESSO-MEMES-1.jpg',
  'https://i.pinimg.com/originals/79/c4/2c/79c42c8b39c575d1838acd7d3bb9a27f.jpg',
  'https://www.hojeemdia.com.br/polopoly_fs/1.778316!/image/image.PNG_gen/derivatives/landscape_653/image.PNG',
  'https://lh3.googleusercontent.com/proxy/ddfE9s3kBwCE_E6WL7pTPmtXjkg3vL3HHS7QqYA6rX7X8thbf3Aj8oyq-KgEkMdR89MExGbBjBi4siCg2tFp1q6PLLbMBodj33iffYKOT4AEV_EDK56p'
];

const rand = list[Math.floor(Math.random() * list.length)];

let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('Meme')
        .setColor('RANDOM')
        .setDescription(`**${message.author} Esse Meme é dos bão!**`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('Memista')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}};