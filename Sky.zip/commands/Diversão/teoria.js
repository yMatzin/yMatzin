const Discord = require("discord.js")

module.exports = {
  name: "teoria",
  aliases: ["teo", "téo"],
  category: "Diversão",

run: async (client, message, args) => {
let array = [
"De 100 em 100 anos, uma super pandemia global pode ser lançada de proposito por causa da super população, como por exemplo. 1920 - peste negra, 2020 - Covid-19.",

"A humanidade querer morar em Marte pode ser apenas uma distração para usar a terra para experimentos perigosos.",

"Como todos sabemos a china lançou um foguete para o espaço sideral, e um pedaço levou exatamente 1 semana e meia para cair, e nisso, os chineses já tinham uma bomba cibernética... Quero dizer que, eles estão sabendo que poderia matar alguem e que iria começar uma guerra mundial contra eles, no caso isso foi de propósito?",

"De antigamente para esses anos todos sabemos que o governo vem escondendo coisas de nós, e eu andei analisando fotos de 1990 até hoje, e andei reparando que não erá para ter tantas nuvens igual tem hoje no verão e no outono, no caso o governo do mundo tudo está criando nuvens para não vermos alguma coisa que está no céu, que não posso falar.",

"Estamos no meio de uma pandemia mundial, absolutamente do nada, os cientista da NASA, IBGE, começa a postar a tal matéria, \"Como sobreviver a um apocalipse zoombie\", ai você se pergunta, oque isso tem haver? Isso pode ser uma das provas que a proxima pandemina mundial que o governo irá lançar, vai ser uma bactéria que é transmitira pela mordida, é que afeita o cérebro de uma maneira forte e boa para a pessoa que contrair ficar inconciente do que está fazendo e ir morrendo aos poucos. ",

"3º guerra mundial ou 1º guerra cibernética?",

"A maioria ficou sabendo que está tendo neve falsa nos Estados Unidos, agora eu me pergunto, porque eles não usam essa neve falsa para diminuir o derretimento da gelera polar antartida? Será que isso é só mais alguma prova para ir a Marte mais rápido?"

]

let msg = array[Math.floor(Math.random() * array.length)]
let embed = new Discord.MessageEmbed()
  .setTitle("Teoria para Você!")
  .setDescription(`${msg}`)
  .setFooter("Caso tenha uma nova teoria contate: <\\yMatzin>#2021")
message.channel.send(embed)
 }
}