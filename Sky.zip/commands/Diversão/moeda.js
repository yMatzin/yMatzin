const Discord = require("discord.js")
 
  module.exports = {
    name: "moeda",
    description: "cara ou coroa '-'",
    author: "Sky",
    aliases: ['coinflip', 'caraoucoroa'],
    category: 'Diversão',

run: async(client, message, args) => {
  
  var array1 = ["cara", "coroa"];
  var rand = Math.floor(Math.random() * array1.length);

  let erro = new Discord.MessageEmbed()
    .setTitle("Cara ou Coroa")
    .setDescription("Você não digitou o comando corretamente\nTente \`s.moeda cara/coroa\`")
    .setFooter("Sky Bot")

  let perdi = new Discord.MessageEmbed()
    .setTitle("Cara ou Coroa")
    .setDescription("Ah, perdi essa! Deu " + array1[rand] + " <:moeda:851760168248934400>")
    .setFooter("Sky Bot")

  let ganhei = new Discord.MessageEmbed()
    .setTitle("Cara ou Coroa")
    .setDescription("Ebaaa, ganhei essa! Deu " + array1[rand] + " <:moeda:851760168248934400>")
    .setFooter("Sky Bot")

  if (!args[0] || (args[0].toLowerCase() !== "cara" && args[0].toLowerCase() !== "coroa")) {
    message.reply(erro);
  } 
else if (args[0].toLowerCase() == array1[rand]) {
    message.channel.send(perdi);
  } 
else if (args[0].toLowerCase() != array1[rand]) {
    message.channel.send (ganhei);
  }
}};