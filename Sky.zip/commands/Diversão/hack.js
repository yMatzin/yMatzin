const discord_akairo_1 = require("discord-akairo");
const Discord = require('discord.js')
const db = require("quick.db")
module.exports = {
    name: 'hack',
    category: 'Diversão',
    
run: async (client, message, args) => {

const user = await message.mentions.users.first()
        if(!user) return message.channel.send("Você precisa mensionar um usuario!")
        
const list = [
'236.384.0.143',
'364.287.0.283',
'634.834.0.348',
'387.230.0.239',
'273.394.0.338'
];

const rand = list[Math.floor(Math.random() * list.length)];

        let embed = new Discord.MessageEmbed()
        .setTitle('Usuario Hackeado!')
        .setDescription(`Email: \`${user.username}@gmail.com\`\nIP: ${rand}`)
        .setFooter('Sky Hacker')

        message.channel.send(`Hackeando @${user.username}`)
        .then((msg) => {
            setTimeout(function() {
            msg.edit(`
<a:emoji_40:842884233915400202> Procurando o IP`);
          }, 1500)
          setTimeout(function() {
            msg.edit(`
<a:emoji_40:842884233915400202> Procurando dados do governo...`);
          }, 4500)
          setTimeout(function() {
            msg.edit(`
<a:emoji_40:842884233915400202> Reportando para ToS discord...`);
          }, 6000)
          setTimeout(function() {
            msg.edit(`
<a:emoji_40:842884233915400202> Procurando e-mail...`);
          }, 7500)
         setTimeout(function() {
            message.channel.send(embed)
         }, 15000)
    })
   
}}