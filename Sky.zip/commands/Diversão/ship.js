const Discord = require("discord.js");

module.exports = {
    name: "ship",
    aliases: ['shipar'],
    category: "Diversão",
run: async (client, message, args) => {

if (!args[0]) return message.channel.send(`${message.author} você precisa Mencionar alguem!`);

 const msg = [
'0% ambos concordaram A FriendZone',
'10% muito dificil',
'20% difícil',
'30% talvez role alguma coisa',
'40% as chances são grandes',
'50% quase certeza que vai rolar!',
'60% pode ser amor verdadeiro',
'70% eles parecem almas gêmeas',
'80% amor verdadeiro',
'90% eles tem que ficar juntos',
'100% Meu Casal :3',
 ]
  var ship = msg[Math.floor(Math.random() * msg.length)];
  let user = message.mentions.users.first() || client.users.cache.get(args[0]);
  
 const ship_msg = new Discord.MessageEmbed()
 .setTitle('🤍** SHIP **🤍')
 .setColor('RANDOM')
 .setTimestamp()
 .setDescription(`Ship de ${message.author} com ${user}`)
   .addFields(
                {
                    name: "**resultados**",
                    value: ship
                },
                    )
 message.channel.send(ship_msg)
}}