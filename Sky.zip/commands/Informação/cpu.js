const Discord = require("discord.js");
const os = require("os");


module.exports = {

  name:"cpu",
  category:"Informações",
  aliases: ['host', 'hostinfo', 'cpuinfo'],
  
run: async (client, message, args, db) => {
  

   if(message.author.id !== "843548736730562580") return message.channel.send("Apenas Devs")

  let modelo = os.cpus().map((i) => `${i.model}`)[0]


  const botinfo = new Discord.MessageEmbed()

  .setColor('#010101')
  .addField(`┃Memória RAM`,`\`${(process.memoryUsage().rss / 1024 / 1024).toFixed(2)}MB de 512MB\``)
  .addField(`┃CPU`, `\`${(process.cpuUsage().system / 1024 / 1024).toFixed(2)}% de CPU\``)
  .addField(`┃Processador`, `\`${modelo}\``)
  message.channel.send(botinfo)
  message.delete();
}}