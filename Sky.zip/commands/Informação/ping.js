const Discord = require("discord.js")

module.exports = {
  name: "ping",
  aliases: ['latencia'],
  category: "Informações",
  run: (client, message, args) => {

    let embed = new Discord.MessageEmbed()

    .setDescription("**Calculando Ping...**")
    .setColor("##8cffd0")
    message.channel.send(embed).then(msg => {
        setTimeout(() => {

            let ping = new Discord.MessageEmbed()
            .setDescription(`**🌐 Ping do Bot** \`${Math.round(client.ws.ping)}ms\`\n**📡Ping do Server** \`${msg.createdTimestamp - message.createdTimestamp}ms\``)
            .setColor("##8cffd0")
            msg.edit(ping)
        }, 100)
    });
}
}
  