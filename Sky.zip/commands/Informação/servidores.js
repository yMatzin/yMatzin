const Discord = require("discord.js");


module.exports = {
    name: "servidores",
    aliases: ['serverlist', 'servers'],
    category: "Informações",
    description: "Displays the list of Servers!",
    usage: " ",
    
  run: async (bot, message, args) => {

      let i0 = 0;
      let i1 = 5;
      let page = 1;

      let description =
        `Servidores totais - ${bot.guilds.cache.size}\n\n` +
        bot.guilds.cache
          .sort((a, b) => b.memberCount - a.memberCount)
          .map(r => r)
          .map((r, i) => `**${i + 1}** - ${r.name} | ${r.memberCount} Membros`)
          .slice(0, 5)
          .join("\n\n");

      let embed = new Discord.MessageEmbed()
        .setAuthor(bot.user.tag, bot.user.displayAvatarURL({dynamic : true}))
        
        .setColor("YELLOW")
        .setFooter(`Página - ${page}/${Math.ceil(bot.guilds.cache.size / 5)}`)
        .setDescription(description);

      let msg = await message.channel.send(embed);

      await msg.react("⬅");
      await msg.react("➡");
      await msg.react("❌");

      let collector = msg.createReactionCollector(
        (reaction, user) => user.id === message.author.id
      );

      collector.on("collect", async (reaction, user) => {
        if (reaction._emoji.name === "⬅") {
          i0 = i0 - 5;
          i1 = i1 - 5;
          page = page - 1;

          if (i0 + 1 < 0) {
            console.log(i0)
            return msg.delete();
          }
          if (!i0 || !i1) {
            return msg.delete();
          }

          description =
            `Servidores totais - ${bot.guilds.cache.size}\n\n` +
            bot.guilds.cache
              .sort((a, b) => b.memberCount - a.memberCount)
              .map(r => r)
              .map(
                (r, i) => `**${i + 1}** - ${r.name} | ${r.memberCount} Membros`)
              .slice(i0, i1)
              .join("\n\n");

          embed
            .setFooter(
              `Páginas - ${page}/${Math.round(bot.guilds.cache.size / 5 + 1)}`
            )
            .setDescription(description);

          msg.edit(embed);
        }

        if (reaction._emoji.name === "➡") {
          i0 = i0 + 5;
          i1 = i1 + 5;
          page = page + 1;

          if (i1 > bot.guilds.cache.size + 5) {
            return msg.delete();
          }
          if (!i0 || !i1) {
            return msg.delete();
          }

          description =
            `Servidores totais - ${bot.guilds.cache.size}\n\n` +
            bot.guilds.cache
              .sort((a, b) => b.memberCount - a.memberCount)
              .map(r => r)
              .map(
                (r, i) => `**${i + 1}** - ${r.name} | ${r.memberCount} Membros`)
              .slice(i0, i1)
              .join("\n\n");

          embed
            .setFooter(
              `Página - ${page}/${Math.round(bot.guilds.cache.size / 5 + 1)}`
            )
            .setDescription(description);

          msg.edit(embed);
        }

        if (reaction._emoji.name === "❌") {
          return msg.delete();
        }

        await reaction.users.remove(message.author.id);
      });
    }
  };