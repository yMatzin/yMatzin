const Discord = require("discord.js");
require('discord-reply')

module.exports = {
  name: "news",
  aliases: ['novos', 'atualização'],
  category: "Informações",

  run: (client, message, args) => {

  let news = new Discord.MessageEmbed()
    .setTitle(`News Do Skyzinhu`)
    .setColor("#FF0000")
    .setFooter(`Sky News`)
    .setDescription(`**Atualizei Recentemente! Veja o que tem de novo:**!`)
    .addFields(
      {
        name: "Adicionados:",
        value: "\`s.teoria - O Bot te conta uma teoria.\`",
        inline: false
      },
      {
        name: "Removidos:",
        value: "\`s.setsaida - Muitos Erros\`",
        inline: false
      },
      {
        name: "Resolvidos:",
        value: "\`s.ticket-setup - Ticket Reação\`",
        inline: false
      },
    );

  message.lineReply(news);
}};