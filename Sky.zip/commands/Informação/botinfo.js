const db = require("quick.db");
const Discord = require ("discord.js")
const { version } = require('../../package.json');
const ms = require('pretty-ms');
const { version: discordjsVersion } = require('discord.js');
module.exports = {

  name: "botinfo",

  category: "Informações",
    aliases: ['binfo', 'botstats', 'stats', 'bi', 'info'],
    description: 'Check\'s bot\'s status',
  run: async (client, message, args, del, member) => {
   message.delete();
      message.channel.send(new Discord.MessageEmbed()
            .setColor('RANDOM')
            .setTitle(`Skyzinhu v3`)
            .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
            .addField('				**❯ Uptime:**', `${ms(client.uptime)}`, true)
            .addField('				**❯ Ping:**', `${client.ws.ping}ms`, true)
            .addField('				**❯ Memoria:**', `${(process.memoryUsage().rss / 1024 / 1024).toFixed(2)} MB RSS\n${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB Heap`, true)
            .addField('				**❯ Servidores:**', `${client.guilds.cache.size} guilds`, true)
            .addField(`				**❯ Usuarios:**`, `${client.users.cache.size} users`, true)
            .addField('				**❯ Comandos:**', `${client.commands.size} cmds`,true)
            .setTimestamp()
        );
    }
}
