const Discord = require ("discord.js")
let owner = "yMatzin#8622"

module.exports = {
    name: "status",
    description: "Info Do Bot",
    category: 'Informações',

    run: async(client, message, args) => {

        let ping = message.author;

        let msg = new Discord.MessageEmbed()
        .setTitle(`<:HI:850924585150316555> Status`)
        .setDescription(`**Abaixo status sobre mim**`)
        .setFooter(`Sky - Todos Os Direitos Reservados ©`)
        .setColor("RANDOM")
        .setTimestamp()
        .addFields(
            {
                name: "Status Bot",
                value: "<:idle:852133456603512912> Atualizações",
                inline: true
            },
            {
                name: "Status Comandos",
                value: "<:online:851841858061598730> Online",
                inline: false
            },
            {
              name: "Ping",
              value: `<:ping:851841857704820768> ${Math.round(client.ws.ping)}ms`,
              inline: false
            },
            {
              name: "Versão",
              value: `<:javascript:851864661359591495> v2.8`,
              inline: false
            },
        );

        message.channel.send(ping, msg)
  
}}