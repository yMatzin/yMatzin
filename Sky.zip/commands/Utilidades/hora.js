const Discord = require('discord.js')
const moment = require('moment'); 

module.exports = {
    name: "hora",
    aliases: ['horario', 'hour'],
    category: "Uteis",
run: async (client, message, args) => {

 moment.locale('pt-br');
 let hora = moment().format('h:mm:ss a');
 let data = moment().format('dddd');
 const embed = new Discord.MessageEmbed()
 .setTitle("Hora 🕒")
 .addField("Hoje é ", `${data}`)
 .addField("As horas são", `${hora}`)

 message.channel.send(embed)

}}