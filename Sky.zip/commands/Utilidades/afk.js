const Discord = require("discord.js"); 
const db = require('quick.db')

module.exports = {
  name: "afk",
  aliases: ['dnd'],
  category: 'Uteis',

  run : async (client, message, args) => {
const status = new db.table("AFKs");
let afk = await status.fetch(message.author.id);
    
let embed1 = new Discord.MessageEmbed()
.setColor('#FF0000')
.setDescription(`**${message.author.tag}** Você Esta No Modo Afk.. \n\n Para sair do Modo Afk , Basta falar no chat. \n **Motivo:** \`${args.join(" ") ? args.join(" ") : "Sem Motivo."}\``)
status.set(message.author.id, args.join(" ") || `AFK`);
if (!afk) return message.channel.send(embed1);

else {

    status.delete(message.author.id);
  }
    
  message.channel.send(embed)
}}