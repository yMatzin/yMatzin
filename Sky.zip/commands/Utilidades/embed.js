const Discord = require("discord.js")
module.exports = {
    name: 'embedgen',
    aliases: ["emb"],
    description: 'embed Generator',
    category: "Uteis",
       run: async (client, message, args) => {

       try {

            const filter = msg => msg.author.id == message.author.id;
            const options = {
                max: 1
            };

            const embed = new Discord.MessageEmbed();
            message.channel.send("**Digite \`skip\` para pular para procima pagia, ou \`cancelar\` para parar de criar sua embed.**");
            
            message.channel.send("Dê um titulo a sua embed");
            let title = await message.channel.awaitMessages(filter, options);
            if (title.first().content == 'cancelar') return message.channel.send('Você cancelou o Gerador De Embed')
            if (title.first().content !== 'skip' && title.first().content !== 'cancelar') embed.setTitle(title.first().content);

            message.channel.send("Dê uma descrição para sua embed.");
            let Description = await message.channel.awaitMessages(filter, options);
            if (Description.first().content == 'cancelar') return message.channel.send('Você cancelou o Gerador De Embed')
            if (Description.first().content !== 'skip' && Description.first().content !== 'cancelar') embed.setDescription(Description.first().content);

            message.channel.send("Você quer um rodapé?");
            let Footer = await message.channel.awaitMessages(filter, options);
            if (Footer.first().content == 'cancelar') return message.channel.send('Você cancelou o Gerador De Embed ')
            if (Footer.first().content !== 'skip' && Footer.first().content !== 'cancelar') embed.setFooter(Footer.first().content); 
            
            message.channel.send("Você quer uma cor? (**\`Em Ingles!\`**)");
            let Color = await message.channel.awaitMessages(filter, options);
            if (Color.first().content == 'cancelar') return message.channel.send('Você cancelou o Gerador De Embed')
            if (Color.first().content !== 'skip' && Color.first().content !== 'cancelar') embed.setColor(Color.first().content.toUpperCase() || "2f3136")
    
            message.channel.send("Quer uma aba de autor?");
            let Author = await message.channel.awaitMessages(filter, options);
            if (Author.first().content == 'cancelar') return message.channel.send('Você cancelou o Gerador De Embed')
            if (Author.first().content !== 'skip' && Author.first().content !== 'cancelar') embed.setAuthor(Author.first().content);

            message.channel.send(embed)
        } catch (error) {
            console.error(error);
        }
    }
}