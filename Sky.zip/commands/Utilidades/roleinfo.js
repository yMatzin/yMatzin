const Discord = require('discord.js') // defining discord

module.exports = {
  name: "roleinfo",
  aliases: ['cargoinfo'],
  category: 'Uteis',

run: async(client, message, args) => {

    let role;

    if (!args[0]) return message.reply('Você precisa mensionar um cargo!') 

    if(args[0] && isNaN(args[0]) && message.mentions.roles.first()) role = message.mentions.roles.first()

    if(args[0] && isNaN(args[0]) && !message.mentions.roles.first()){ 
        
      role = message.guild.roles.cache.find(e => e.name.toLowerCase().trim() == args.slice(0).join(" ").toLowerCase().trim()) 

      if(!message.guild.roles.cache.find(e => e.name.toLowerCase().trim() == args.slice(0).join(" ").toLowerCase().trim())) return message.reply("Esse cargo não existe e/ou é invalido!")
    }

    if(args[0] && !isNaN(args[0])){

      role = message.guild.roles.cache.find(e => e.id == args[0])

      if(!message.guild.roles.cache.has(args[0])) return message.reply("O ID é invialido!")
    }
 
    if(!role) return message.reply("Você precisa mensionar um cargo, me dar um ID ou falar o nome pelo menos")


  let WithRole;

  if(role.members.size > 5) WithRole = role.members.map(e => `<@${e.id}>`).slice(0,5).join(", ") + ` and ${role.members.size - 5} more members...` 

  if(role.members.size < 5) WithRole = role.members.map(e => `<@${e.id}>`).join(", ")
    
  // create an embed
    let embed = new Discord.MessageEmbed()
    .setColor(role.color) // the color of the embed will be the role color
    .setAuthor(message.guild.name, message.guild.iconURL()) 
    .setDescription(`**Nome:** ${role.name}
    **ID:** **\`${role.id}\`**
    **Mensionavel:** ${role.mentionable.toString().replace("true","Yes").replace("false","No")}
    **Membros:** ${role.members.size || 0}`)

  .addField("Role Members:",WithRole ? WithRole : "Não há ninguem com esse cargo :(")
  
    message.channel.send(embed) // then it gonna send the embed
  }}