const Discord = require("discord.js");

module.exports = {
    name: "youtube",
    aliases: ['ytbr', 'searchyt'],
    category: "Uteis",
run: async (client, message, args) => {
let link = args.join(' ')    
 
 let noArgs = new Discord.MessageEmbed()
 .setColor('RED') //escolha uma cor 
 .setDescription(`você deve colocar algo para pesquisar!`) 

if(!args[0]) return message.channel.send(noArgs);

 const embed = new Discord.MessageEmbed()
 .setTitle (`Sua pesquisa no google`)
 .setColor('RED') //escolha uma cor 
 .setDescription (`[Clique Aqui](https://www.youtube.com/results?search_query=${link}) para ir na sua pesquisa no youtube`)
 .setThumbnail ("https://www.youtube.com/s/desktop/df22805b/img/favicon_144.png")
message.channel.send(embed)

}};