const Discord = require('discord.js')

module.exports = {
    name: "conviar",
    aliases: ["invite", "convite"],
    category: 'Uteis',
    cooldown: 10,
    async run(client, message, args) {

const invite = new Discord.MessageEmbed()
  .setAuthor(`Invite Bot`, client.user.displayAvatarURL())
  .setDescription(`**Olá ${message.author.username} vejo que você quer me adicionar em seu servidor! \n Para me adicionar [Clique Aqui](https://discord.com/oauth2/authorize?client_id=${client.user.id}&scope=bot&permissions=2147483647)**`)
  .setColor("BLUE")
  message.channel.send(invite)
}}