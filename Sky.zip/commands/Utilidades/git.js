const Discord = require("discord.js")

module.exports = {
  name: "git",
  aliases: ['repo'],
  category: 'Uteis',

run: async(client, message, args) => {
  const git = await message.channel.send('🔎 Procurando repo...');

  git.edit(`📌 Repo encontrado com sucesso!
  **Acesse:** https://github.com/${args[0]}`);
}};