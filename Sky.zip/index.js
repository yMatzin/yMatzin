const enmap = require('enmap');

const settings = new enmap({
    name: "settings",
    autoFetch: true,
    cloneLevel: "deep",
    fetchAll: true
});

client.on('message', async message => {
    if(message.author.bot) return;
    if(message.content.indexOf(prefix) !== 0) return;
;

    const prefix_detect = message.content.slice(prefix.length).trim().split(/ +/g);
    const command_detect = prefix_detect.shift().toLowerCase();
    const emoji = "🎫";

        let ticket_ok = new Discord.MessageEmbed()
            .setTitle("✅ |Sistema de Ticket")
            .setDescription("Você configurou o sistema de ticket com sucesso!")
            .setFooter("Sistema de Ticket")
            .setColor("RANDOM")

        let ticket_error = new Discord.MessageEmbed()
            .setTitle("❌ |Sistema de Ticket")
            .setDescription("Você errou ao digitar o comando!\n✅ |O correto: \`s.ticket-setup #canal\`")
            .setFooter("Sistema de Ticket")
            .setColor("RANDOM")

    if(command_detect == "ticket-setup") {

        let error = message.mentions.channels.first();
        if(!error) return message.reply(ticket_error);

        let ticket = await error.send(new Discord.MessageEmbed()
            .setTitle("Sistema de Ticket")
            .setDescription("Reaja 🎫 para abrir um ticket!\nPara fecha-lo, utilize s.close!")
            .setFooter("Sistema de Ticket")
            .setColor("RANDOM")
        );

        ticket.react(emoji);
        settings.set(`${message.guild.id}-ticket`, ticket.id);

        message.channel.send(ticket_ok)
    }

    if(command_detect == "close") {
        if(!message.channel.name.includes("ticket-")) return message.channel.send("Você não pode utilizar esse comando aqui!")
        message.channel.delete();
    }
});

client.on('messageReactionAdd', async (reaction, user) => {
  const ticket_emoji = "🎫";
    if(user.partial) await user.fetch();
    if(reaction.partial) await reaction.fetch();
    if(reaction.message.partial) await reaction.message.fetch();

    if(user.bot) return;

    const ticket = await settings.get(`${reaction.message.guild.id}-ticket`);

    if(!ticket) return;

    if(reaction.message.id == ticket && reaction.emoji.name == ticket_emoji) {
        reaction.users.remove(user);

        reaction.message.guild.channels.create(`ticket-${user.username}`, {
            permissionOverwrites: [
                {
                    id: user.id,
                    allow: ["SEND_MESSAGES", "VIEW_CHANNEL"]
                },
                {
                    id: reaction.message.guild.roles.everyone,
                    deny: ["VIEW_CHANNEL"]
                }
            ],
            type: 'text'
        }).then(async ticket => {
            ticket.send(`<@${user.id}>`, new Discord.MessageEmbed().setTitle("Boas vindas ao seu ticket").setDescription("Para fecha-lo, utilize \`s.close\`").setColor("RANDOM"));
            
        })
    }
});

client.login(process.env.TOKEN);